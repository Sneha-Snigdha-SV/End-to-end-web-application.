from fastapi import FastAPI, Request, Response, Form
from fastapi.responses import HTMLResponse
from typing import List ,Optional,Union,Any
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from pymongo import MongoClient
from pydantic import BaseModel
from pathlib import Path
import bcrypt
import pymongo




base_dir= Path(__file__).resolve().parent

app = FastAPI()
# Define the default context (adjust as needed)
context = {}
app.mount("/static", StaticFiles(directory=str(Path(base_dir,"static/"))) ,name="static")
templates=Jinja2Templates(directory="templates")
client = pymongo.MongoClient("mongodb+srv://sneha:sneha%40123@cluster0.pmrz3yt.mongodb.net/ttd")
#client = pymongo.MongoClient("mongodb+srv://sneha:sneha%40123@cluster0.sur1pof.mongodb.net/ttd")
db = client["ttd"]

users_collection = db["users"]
bhajanamandiralu_collection = db["bhajanamandiralu"]


class User(BaseModel):
    username: str
    phonenumber: int
    password: str
    cpassword: str
    email: str
    role: str

class Login(BaseModel):
    username: str
    password: str

class Bhajanamandiralu(BaseModel):
    phases: int
    district: str
    assemblycostituency: str
    mandal: str
    village: str
    colony: str
    lattitude: float
    longitude: float
    population: int
    specification: str
    requestee: str
    temple: str
    file: str
    email: str


@app.get("/")
async def login(request:Request):
    return templates.TemplateResponse ("login.html",{"request":request})

@app.get("/signup")
async def Users(request:Request):
    return templates.TemplateResponse ("signup.html",{"request":request})

@app.get("/bhajanamandiralu")
async def bhajanamandiralu_form(request:Request):
    return templates.TemplateResponse ("bhajanamandiralu.html",{"request":request})

@app.get("/reports", response_class=HTMLResponse)
async def report(request:Request):
    c=True
    return templates.TemplateResponse ("report.html",{"request":request, "c": c})

@app.post("/signup")
async def Users(request:User):
    username = request.username 
    phonenumber= request.phonenumber
    password=request.password.encode()
    cpassword=request.cpassword.encode()
    email=request.email
    role=request.role
    # Hashing the Password
    hashedPassword = bcrypt.hashpw(password,bcrypt.gensalt())
    hashedConfirmPassword = bcrypt.hashpw(cpassword,bcrypt.gensalt())

    if len(username)==0:
         return "user dosen't exist"
    else:
        data = {
        "username": username,
        "phonenumber":phonenumber,
        "password":password,
        "cpassword":cpassword,
        "email":email,
        "role":role,
         }
        users_collection.insert_one(data)
        print(data)
        return "success" 


    
@app.post("/")
async def login(request:Login, response: Response):
    username = request.username 
    password = request.password
    password = password.encode("utf-8")
    Userdata= users_collection.find({"username":username},{"_id":0})
    if not Userdata:
        return{"UnSuccess"}
    else:
        hashed_password = Userdata["password"]
        hashed_password=hashed_password.encode("utf-8")
        # comparing Password with hashed Password
        if bcrypt.checkpw(password, hashed_password): 
            return{"Success"}
        else:
            return{"UnSuccess"} 
    # result = list(data)

    # global login_user_name

    # if len(result)==0:
    #     return "User not found"
    # else:
    #     password = result[0]["password"]
    #     login_user_name = result[0]["username"]
    #     return 'Login successfull!' 

"""async def UserAccount(request:LoginUser):
    Username = request.Username
    Password = request.Password.encode()
    Userdata = mycol.find_one({"Username":Username},{"_id":0})
    if not Userdata:
        return{"UnSuccess"}
    else:
        hashed_password = Userdata["Password"].encode()
        # comparing Password with hashed Password
        if bcrypt.checkpw(Password, hashed_password): 
            return{"Success"}
        else:
            return{"UnSuccess"} """

    
@app.post("/bhajanamandiralu")
async def submit_bhajanamandiralu(request:Bhajanamandiralu):
    phases = request.phases
    district = request.district
    assemblycostituency = request.assemblycostituency
    mandal = request.mandal
    village = request.village
    colony = request.colony
    lattitude = request.lattitude
    longitude = request.longitude
    population = request.population
    specification = request.specification
    requestee = request.requestee
    temple = request.temple
    file = request.file
    email = request.email

    data = {
            "phases" : phases,
            "district" : district,
            "assemblycostituency" :assemblycostituency,
            "mandal" :  mandal,
            "village" : village,
            "colony" : colony,
            "lattitude" : lattitude,
            "longitude" : longitude,
            "population" : population,
            "specification" : specification,
            "requestee" : requestee,
            "temple" : temple,
            "file" : file,
            "email" : email,
            }
    result = list(data)
    bhajanamandiralu_collection.insert_one(data)
    if len(result)==0:
        return "No Data inserted"
    else:
        return "Details submitted" 

"""@app.post('/reports')

async def GetApplicationsByDistrict(request: Request, district: Optional[List] = Form(default=None), phases: Optional[List] = Form(default=None)):
context = {"request": request}
ReportsData = []

if district and not phases:
    for d in district:
        Data = bhajanamandiralu_collection.find({"district": d}).sort("_id", 1)
             for i in Data:
                 data = {"district": d, "request_data": i}
                 ReportsData.append(data)

     elif district and phases:
         for d, p in zip(district, phases):
             Data = bhajanamandiralu_collection.find({"district": d, "phases": p}).sort("_id", 1)
             for i in Data:
                 data = {"district": d, "phases": p, "request_data": i}
                 ReportsData.append(data)
c = bool(ReportsData)
return templates.TemplateResponse('report.html', {"ReportsData": ReportsData, "district": district, "phases": phases, "c": c, **context})"""

"""@app.post('/reports',response_class=HTMLResponse)
async def GetApplicationsByDistrict(request: Request,district: Optional[List] = Form(default=None),phases: Optional[List] = Form(default=None)
):
    context = {"request": request}
    ReportsData = []

    if district and not phases:
        for d in district:
            Data = bhajanamandiralu_collection.find({"district": d}).sort("_id", 1)
            for i in Data:
                data = {"district": district, "request_data": i}
                ReportsData.append(data)

    elif district and phases:
        for d,p in zip(district,phases):
            Data = bhajanamandiralu_collection.find({"district": d, "phases": p}).sort("_id", 1)
            for i in Data:
                data = {"district": d, "phases": p, "request_data": i}
                ReportsData.append(data)

    c = bool(ReportsData)
    print(ReportsData)
    return templates.TemplateResponse('report.html', {"ReportsData": ReportsData, "district": district, "phases": phases, "c": c, **context})"""

@app.post("/reports")
# async def GetApplicationsByDistrict(request: Request, district: Optional[List] = Form(default=None), phases: Optional[List] = Form(default=None)):
# context = {"request": request}
# ReportsData = []
def process_data(request: Request,district:Optional[List] = Form(default=None), specification:Optional[List] = Form(default=None)):
    context = {"request": request}
   
    if district:

        print("this is district details:", district)
        ReportsData = []
        for d in district:
            Data = bhajanamandiralu_collection.find({"district": d}).sort("_id", 1)
            for i in Data:
                data = {"district": d, "request_data": i}
                ReportsData.append(data)
        c = True
        return templates.TemplateResponse('report.html', {"ReportsData": ReportsData, "district": district, "c": c, **context})

    elif specification:
            print("this is specification details:", specification)
            ReportsData = []
            for d in specification:
                Data = bhajanamandiralu_collection.find({"specification": d}).sort("_id", 1)
                for i in Data:
                    data = {"specification": d, "request_data": i}
                    ReportsData.append(data)
            c = True
            return templates.TemplateResponse('report.html', {"ReportsData": ReportsData, "specification": specification, "c": c, **context})
   