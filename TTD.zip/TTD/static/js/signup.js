async function update() {
    var username=document.getElementById("usename").value;
    var phonenumber=document.getElementById("phonemunber").value;
    var password=document.getElementById("password").value;
    var cpassword=document.getElementById("cpassword").value;
    var email=document.getElementById("email").value;
    var role=document.getElementById("role").value;

    if(
        username != "" &&
        phonenumber != ""&&
        password != "" &&
        cpassword != "" &&
        email != "" &&
        role != "" 
    ) {
        var myHeaders = new Headers();
        myHeaders.append("Content-Type","application/json");

        var raw=JSON.stringify({

            username: username,
            phonenumber: phonenumber,
            password: password,
            cpassword:cpassword,
            email:email,
            role:role,
        });

        var requestOptions = {
            method:"POST",
            headers: myHeaders,
            body: raw,
            redirect: "follow",

        };

        console.log(raw);

        var config={

            method: "post",
            url: "/signup",
            headers: {
                "Content-Type": "application/json",
                },
                data: raw,

            };

            const response=await axios(config);
            const resp = response.data;

            connsole.log(resp);

            if (resp==="Success") {
                alert("Details saved successfully !");
                window.location.href = "/signup";
            }
            else {
                alert("Error while saving the details");
            }
        }
        else {
            alert("Please enter all the details")
        
    }
}